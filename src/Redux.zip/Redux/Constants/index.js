export default BASEURLS = {
  MainUrl: 'http://demo.webshowcase-india.com/abtyp/index.php/api/',
};