export default BASEURLS = {
  MainUrl: 'https://demo.webshowcase-india.com/indiadeposit/public/apis/',
};