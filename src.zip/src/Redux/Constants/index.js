export default BASEURLS = {
    MainUrl:'https://demo.webshowcase-india.com/indiadeposit/public/apis/',
    //  MainUrl: 'http://indiadeposit.in/admin/public/apis/',
};