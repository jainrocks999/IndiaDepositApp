export default {
  bc:'#5A4392',
  textColor:'#000',
  white:'#fff'
  };
