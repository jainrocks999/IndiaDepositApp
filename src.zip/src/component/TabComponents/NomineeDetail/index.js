import React from 'react';
import { View,Text } from 'react-native';

const Nominee=()=>{
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text>Working</Text>
        </View>
    )
}
export default Nominee