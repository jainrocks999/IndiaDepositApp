export default BASEURLS = {
     imageUrl:'https://indiadeposit.in/admin/writable/uploads/bank/'
};