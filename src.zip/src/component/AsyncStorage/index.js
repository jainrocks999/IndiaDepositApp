export default {
    user_id:'user_id',
    
    mobile:'mobile',
    name:'name',
    email:'email',
    dob:'dob',
    fatherName:'fatherName',
    motherName:'motherName',
    gender:'gender',
    photo:'photo',
    token:'token',
    image:'image',
    status:'status'
}