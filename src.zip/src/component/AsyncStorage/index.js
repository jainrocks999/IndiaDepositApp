export default {
    userid:'userid',
    email:'email',
    mobile:'mobile',
    name:'name',
    photo:'photo'
}